<footer class=" sticky-footer" style="background: #d1d1d1;">
    <div class="container my-auto">
        <div class="text-center my-auto copyright"><span>SPDM © 2023</span></div>
    </div>
</footer>