<?php

namespace PagarMe;

class PagarMe
{
    const VERSION = '4.1.2';
}
