<?php

    //rotas

        // Pagina Inicial
            $index = 'index.php';
            $login = 'login.php';
            $cadastrar = 'app/cadastrar.php';
            $expass = 'expass.php';

        // APP
            $logout = '../php/funcoes/login/logout.php';
            $wallet = 'wallet.php';
            $cupons = 'cupons.php';
            $extrato = 'extrato.php';
            $nfts = '#';
            $perfil = 'perfil.php';
            $pesquisa = 'pesquisa.php';
            $novo_usuario = 'novousuario.php';
            $adc_saldo = 'adc_saldo.php';

            $pendencia = 'pendencia.php';
            $historico = 'historico.php';
            $estoque = 'estoque.php';
            $reserva = 'reserva.php';

?>