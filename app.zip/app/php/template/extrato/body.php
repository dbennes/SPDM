<div id="content">
    <div class="container-fluid">
        <div class="card shadow" style="border: none; background: #181818;">
            <div class="card-header py-3" style="border: none; background: #181818;">
                <p class="m-0 fw-bold" style="color: rgb(61,61,61);">Extrato</p>
            </div>
            <div class="card-body" style="border: none; background: #181818;">
                
                <div class="table-responsive table mt-2" id="dataTable" role="grid" aria-describedby="dataTable_info">
                    <table class="table my-0" id="dataTable">
                        <thead>
                            <tr>
                                <th style="font-size: 12px;">Jogo</th>
                                <th style="font-size: 12px;">Valor</th>
                                <th style="font-size: 12px;">Minutos</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            <?php 
                            
                                $GetDados2 = ("SELECT * FROM extrato WHERE cpf = '$cpf'");
                                $GetDadosquery2 = mysqli_query($conecta, $GetDados2) or mysqli_error($conecta);
                                $row2 = mysqli_num_rows ($GetDadosquery2);
                            
                                if ($row2 > 0) {
                                    while ($GetDadosline2 = mysqli_fetch_array($GetDadosquery2)) {     
                                        $jogo = $GetDadosline2 ['jogo'];
                                        $valor = $GetDadosline2 ['valor_descontado'];
                                        
                                        $min = $valor/2;
                                
                            
                            ?>

                            <tr>
                                <td><?php echo $jogo; ?></td>
                                <td><?php echo "R$ -".$valor.",00"; ?></td>
                                <td><?php echo $min . "min"; ?></td>
                            </tr>

                            <?php }} ?>
                        </tbody>
                        <tfoot>
                            <tr></tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
            
<!-- FOOTER -->
