<div class="container-fluid">
    <h3 class="text-dark mb-4">Insira os dados do Cliente:</h3>
    <div class="row mb-3">
        <div class="col-lg-12">
            <div class="row">
                <div class="col-md-4 col-xs-6">
                    <div class="card shadow mb-3" style="border: none; background: #181818;">
                        <div class="card-header py-3" style="border: none; background: #181818;">
                            <p class=" m-0 fw-bold">Dados do Cliente</p>
                        </div>
                        <div class="card-body" style="border: none; background: #181818;">
                            <form action="php/funcoes/queries/adc_saldo.php" method="POST">
                                <div class="row">
                                    <div class="col">
                                        <div class="mb-3">
                                            <label class="form-label" for="username">
                                                <strong>CPF:</strong>
                                            </label>
                                            <input style="background: #212121; border:none; " class="form-control" type="text" id="cpf" placeholder="Insira o CPF" name="cpf" value="" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col">
                                        <div class="mb-3">
                                            <label class="form-label" for="email">
                                                <strong>ADC. SALDO:</strong>
                                            </label>
                                            <input class="form-control" style="background: #212121; border:none; " type="number" id="novo_saldo" value="" placeholder="R$" name="novo_saldo" min="10" required>
                                        </div>
                                    </div>
                                </div>
                                <button class="btn d-block btn-user w-100" type="submit" style="background: black;color: rgb(255,255,255); margin: 0px;">REGISTRAR DADOS</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>