<nav class="navbar navbar-dark align-items-start sidebar sidebar-dark accordion bg-gradient-primary p-0" style="background: rgb(12,12,12);">
            <div class="container-fluid d-flex flex-column p-0"><a class="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" href="#">
                    <div>
                        <img class="img-profile" src="assets/img/PERFIL%20(BRANCO)%20(1).png" style="width: 41px;border: 0px solid rgb(0,0,0);border-radius: 9px;">
                    </div>
                    <div class="sidebar-brand-text mx-3">
                        <span style="color: rgb(59,59,59);">EXVERSE</span>
                    </div>
                </a>
                <hr class="sidebar-divider my-0">
                <ul class="navbar-nav text-light" id="accordionSidebar">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo $wallet; ?>">
                            <i class="fas fa-wallet" style="color: #444444;"></i>
                            <span style="color: #444444;">Wallet</span>
                        </a>
                        <a class="nav-link" href="<?php echo $cupons; ?>">
                            <i class="fas fa-store" style="color: #444444;"></i>
                            <span style="color: #444444;">Cupons</span>
                        </a>
                    </li>
                    <li class="nav-item" style="color: #444444;">
                        <a class="nav-link " href="<?php echo $extrato; ?>" style="color: #444444;">
                            <i class="fas fa-table" style="color: #444444;"></i>
                            <span style="color: #444444;">&nbsp;Extrato</span>
                        </a>
                        <a class="nav-link" href="<?php echo $nfts; ?>" style="color: #444444;">
                            <i class="fas fa-link" style="color: #444444;"></i>
                            <span style="color: #444444;">NFTs</span>
                        </a>
                    </li>
                    <li class="nav-item" style="color: #444444;">
                        <a class="nav-link " href="<?php echo $perfil; ?>" style="color: #444444;">
                            <i class="fas fa-user" style="color: #444444;"></i>
                            <span style="color: #444444;">Perfil</span>
                        </a>
                    </li>

                    <?php    
                        if ($acesso>=2) {   
                    ?>

                        <li class="nav-item" style="color: #444444; background: #000000">
                            <a class="nav-link active" href="<?php echo $adm; ?>" style="color: #444444;">
                                <i class="fas fa-user-clock" style="color: #e30000;"></i>
                                <span style="color: #5d5d5d;">Descontar</span>
                            </a>
                        </li>
                        <li class="nav-item" style="color: #444444; background: #000000">
                            <a class="nav-link active" href="<?php echo $novo_usuario; ?>" style="color: #444444;">
                                <i class="fas fa-user-plus" style="color: #5c0fa3;"></i>
                                <span style="color: #5d5d5d;">New User</span>
                            </a>
                        </li>
                        <li class="nav-item" style="color: #444444; background: #000000">
                            <a class="nav-link active" href="<?php echo $adc_saldo; ?>" style="color: #444444;">
                                <i class="fas fa-user-plus" style="color: #339b22;"></i>
                                <span style="color: #5d5d5d;">Adc. Saldo</span>
                            </a>
                        </li>
                        <li class="nav-item" style="color: #444444; background: #000000">
                            <a class="nav-link active" href="<?php echo $usuarios; ?>" style="color: #444444;">
                                <i class="fas fa-user-plus" style="color: #9d9d9d;"></i>
                                <span style="color: #5d5d5d;">Usuarios</span>
                            </a>
                        </li>

                    <?php    
                        }   
                    ?>

                    <li class="nav-item" style="color: #444444;">
                        <a class="nav-link" href="<?php echo $logout; ?>" style="color: #444444;">
                            <i class="fas fa-times" style="color: #444444;"></i>
                            <span style="color: #444444;">Sair</span>
                        </a>
                    </li>
                </ul>
                <div class="text-center d-none d-md-inline">
                    <button class="btn rounded-circle border-0" id="sidebarToggle" type="button"></button>
                </div>
            </div>
        </nav>