<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>EXBANK</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i&amp;display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/menu-footer.css">

    <meta name="description" content="A primeira empresa brasileira a trazer o conceito de metaverso de forma inovadora em shoppings.">
    <link rel="icon" type="image/png" sizes="2166x2166" href="../assets/img/Perfil%2003%20(1).png">
    <link rel="icon" type="image/png" sizes="2166x2166" href="../assets/img/Perfil%2003%20(1).png">
    <link rel="icon" type="image/png" sizes="2166x2166" href="../assets/img/Perfil%2003%20(1).png">
    <link rel="icon" type="image/png" sizes="2166x2166" href="../assets/img/Perfil%2003%20(1).png">
    <link rel="icon" type="image/png" sizes="2166x2166" href="../assets/img/Perfil%2003%20(1).png">
</head>