<div id="content">
    <div class="container-fluid">
        <div class="card shadow" style="border: none; background: #181818;">
            <div class="card-header py-3" style="border: none; background: #181818;">
                <p class="m-0 fw-bold" style="color: white;">Usuarios</p>
            </div>
            <div class="card-body" style="border: none; background: #181818;">
                
                <div class="table-responsive table mt-2" id="dataTable" role="grid" aria-describedby="dataTable_info">
                    <table class="table my-0" id="dataTable">
                        <thead>
                            <tr>
                                <th style="font-size: 12px;">ID</th>
                                <th style="font-size: 12px;">NOME</th>
                                <th style="font-size: 12px;">CPF</th>
                                <th style="font-size: 12px;">CONTATO</th>
                                <th style="font-size: 12px;">SALDO</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            <?php 
                            
                                $GetDados2 = ("SELECT * FROM user ");
                                $GetDadosquery2 = mysqli_query($conecta, $GetDados2) or mysqli_error($conecta);
                                $row2 = mysqli_num_rows ($GetDadosquery2);
                            
                                if ($row2 > 0) {
                                    while ($GetDadosline2 = mysqli_fetch_array($GetDadosquery2)) {     
                                        $ID = $GetDadosline2 ['id_user'];
                                        $NOME = $GetDadosline2 ['nome'];
                                        $CPF = $GetDadosline2 ['cpf'];
                                        $CONTATO = $GetDadosline2 ['contato'];
                                        $SALDO = $GetDadosline2 ['saldo'];
                                        
                                
                            
                            ?>

                            <tr>
                                <td><?php echo $ID; ?></td>
                                <td><?php echo $NOME; ?></td>
                                <td><?php echo $CPF; ?></td>
                                <td><?php echo $CONTATO; ?></td>
                                <td><?php echo "R$ ".$SALDO.",00"; ?></td>
                            </tr>

                            <?php }} ?>
                        </tbody>
                        <tfoot>
                            <tr></tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
            
<!-- FOOTER -->
