<div class="container-fluid">
    <div class="d-sm-flex justify-content-between align-items-center mb-4">
        <h3 class="text-dark mb-0">Welcome <br>to the Family!</h3>
        <p>#THE.FUTURE.IS.NOW</p><a class="btn btn-primary btn-sm d-none d-sm-inline-block" role="button" href="#"><i class="fas fa-download fa-sm text-white-50"></i>&nbsp;Generate Report</a>
    </div>
    <div class="row">
        <div class="col-md-6 col-xl-3 mb-4">
            <div class="card shadow border-start-primary py-2" style="border: none; background: #181818;">
                <div class="card-body">
                    <div class="row align-items-center no-gutters">
                        <div class="col me-2">
                            <div class="text-uppercase fw-bold text-xs mb-1" style="color: #e5e5e5;"><span style="color: #e5e5e5;">saldo (mÊs)</span></div>
                            <div class="fw-bold h5 mb-0" style="color: #8f8f8f;"><span>R$ <?php echo number_format($saldo, 2, ',', '.') ; ?></span></div>
                        </div>
                        <div class="col-auto"><i class="fas fa-dollar-sign fa-2x text-gray-300"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xl-3 mb-4">
            <div class="card shadow border-start-success py-2" style="border: none; background: #181818;">
                <div class="card-body">
                    <div class="row align-items-center no-gutters">
                        <div class="col me-2">
                            <div class="text-uppercase text-success fw-bold text-xs mb-1"><span style="color: #e5e5e5;">GANHOS&nbsp; (NFTs)</span></div>
                            <div class=" fw-bold h5 mb-0" style="color: #8f8f8f;"><span>R$ 0,00</span></div>
                        </div>
                        <div class="col-auto"><i class="fas fa-link fa-2x text-gray-300"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xl-3 mb-4">
            <div class="card shadow border-start-info py-2" style="border: none; background: #181818;">
                <div class="card-body">
                    <div class="row align-items-center no-gutters">
                        <div class="col me-2">
                            <div class="text-uppercase text-info fw-bold text-xs mb-1"><span style="color: #e5e5e5;">CARTÃO HASH</span></div>
                            <div class="row g-0 align-items-center">
                                <div class="col-auto">
                                    <div class="fw-bold h5 mb-0 me-3">
                                        <span style="font-size: 16px; color: #8f8f8f;">#<?php echo $card; ?></span></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-auto"><i class="far fa-credit-card fa-2x text-gray-300"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xl-3 mb-4">
            <div class="card shadow border-start-primary py-2" style="border: none; background: #181818;">
                <div class="card-body">
                    <div class="row align-items-center no-gutters">
                        <div class="col me-2">
                            <div class="text-uppercase fw-bold text-xs mb-1" style="color: #e5e5e5;"><span style="color: #e5e5e5;">N3X (TOKEN)</span></div>
                            <div class="fw-bold h5 mb-0" style="color: #8f8f8f;"><span>$ 0,00</span></div>
                        </div>
                        <div class="col-auto"><i class="fab fa-bitcoin fa-2x text-gray-300"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>