<footer class=" sticky-footer" style="background: #1c1c1c;">
    <div class="container my-auto">
        <div class="text-center my-auto copyright"><span>EXVERSE © 2021</span></div>
    </div>
</footer>