<div class="container-fluid">
    <h3 class="text-dark mb-4">Insira os dados do Cliente:</h3>
    <div class="row mb-3">
        <div class="col-lg-12">
            <div class="row">
                <div class="col-md-4 col-xs-6">
                    <div class="card shadow mb-3" style="border: none; background: #181818;">
                        <div class="card-header py-3" style="border: none; background: #181818;">
                            <p class=" m-0 fw-bold">Dados do Cliente</p>
                        </div>
                        <div class="card-body" style="border: none; background: #181818;">
                            <form action="php/funcoes/queries/descontar.php" method="POST">
                                <div class="row">
                                    <div class="col">
                                        <div class="mb-3">
                                            <label class="form-label" for="username">
                                                <strong>CPF:</strong>
                                            </label>
                                            <input style="background: #212121; border:none; " class="form-control" type="text" id="cpf" placeholder="Insira o CPF" name="cpf" value="" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col">
                                        <div class="mb-3">
                                            <label class="form-label" for="email">
                                                <strong>VALOR A DESCONTAR:</strong>
                                            </label>
                                            <input class="form-control" style="background: #212121; border:none; " type="number" id="valor" value="" placeholder="R$" name="valor" min="10" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col">
                                        <div class="mb-3">
                                            <label class="form-label" for="last_name">
                                                <strong>GAME:</strong>
                                            </label>
                                            <select style="background: #212121; border:none; " class="form-select" aria-label="Default select example" name="jogo" required>
                                                <option selected>Selecione o Game</option>
                                                <option value="ARENA EXVERSE">ARENA EXVERSE</option>
                                                <option value="SPACE EXVERSE">SPACE EXVERSE</option>
                                                <option value="3BEAT SABER">BEAT SABER</option>
                                                <option value="ANCIENT DUGEON">ANCIENT DUGEON</option>
                                                <option value="ONWARD">ONWARD</option>
                                                <option value="CREED">CREED</option>
                                                <option value="RESIDENT EVIL">RESIDENT EVIL</option>
                                                <option value="POPULATION ONE">POPULATION ONE</option>
                                                <option value="MEDALHA DE HONRA">MEDALHA DE HONRA</option>
                                                <option value="SIMULADOR">SIMULADOR</option>
                                                <option value="NINTENDO">NINTENDO</option>
                                                <option value="XBOX">XBOX</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <button class="btn d-block btn-user w-100" type="submit" style="background: black;color: rgb(255,255,255); margin: 0px;">REGISTRAR DADOS</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-md-8 col-xs-6">
                    <div class="card shadow mb-3" style="border: none; background: #181818;">
                        <div class="card-header py-3" style="border: none; background: #181818;">
                            <p class=" m-0 fw-bold">Dados do Cliente</p>
                        </div>
                        <div class="card-body" style="border: none; background: #181818;">
                            
                                <div class="row">
                                   
                                </div>
                                
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>