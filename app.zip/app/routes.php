<?php

    //rotas

        // Pagina Inicial
            $index = 'index.php';
            $login = 'login.php';
            $cadastrar = 'app/cadastrar.php';
            $expass = 'expass.php';

        // APP
            $logout = 'php/funcoes/login/logout.php';
            $cupons = 'produtos.php';
            $extrato = 'carrinho.php';
            $nfts = 'carrinho.php';
            $perfil = 'carrinho.php';
            
            

            
            




?>