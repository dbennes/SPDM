<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>SPDM</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i&amp;display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/menu-footer.css">

    <meta name="description" content="A primeira empresa brasileira a trazer o conceito de metaverso de forma inovadora em shoppings.">
    <!-- <link rel="icon" type="image/png" sizes="2166x2166" href="../assets/img/Perfil%2003%20(1).png">
    <link rel="icon" type="image/png" sizes="2166x2166" href="../assets/img/Perfil%2003%20(1).png">
    <link rel="icon" type="image/png" sizes="2166x2166" href="../assets/img/Perfil%2003%20(1).png">
    <link rel="icon" type="image/png" sizes="2166x2166" href="../assets/img/Perfil%2003%20(1).png">
    <link rel="icon" type="image/png" sizes="2166x2166" href="../assets/img/Perfil%2003%20(1).png"> -->

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js"></script>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>

    
</head>