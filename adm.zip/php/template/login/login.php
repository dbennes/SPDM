<section class="py-4 py-md-5 my-5" style="background:  #e9e9e9;;">
    <div class="container py-md-5">
        <div class="row">
            <div class="col-md-12 text-center d-flex justify-content-center" style="padding-top: 21px;">
           
            <div class="col-md-5 col-xl-4 text-center text-md-start ">
                <h2 class="display-6 fw-bold mb-5" style="padding-top: 17px;">
                    <span class="underline pb-1">
                        <strong style="font-family: Montserrat, sans-serif;border-style: none;font-size: 18px;font-weight: normal; color: #7b7b7b;">#.PESQUISA DE MATERIAIS</strong><br>
                    </span>
                </h2>
                <form action="./php/funcoes/login/loginpage.php" method="POST">
                    <div class="d-flex d-sm-flex d-md-flex d-lg-flex d-xl-flex justify-content-center align-items-center justify-content-sm-center align-items-sm-center justify-content-md-center align-items-md-center justify-content-lg-center align-items-lg-center mb-3">
                        <input style="width: 90%;color: #7b7b7b; background: #d5d5d5; border:none;" class=" form-control" type="email" name="email" placeholder="Email">
                    </div>
                    <div class="d-flex d-sm-flex d-md-flex d-lg-flex d-xl-flex justify-content-center align-items-center justify-content-sm-center align-items-sm-center justify-content-md-center align-items-md-center justify-content-lg-center align-items-lg-center mb-3">
                        <input style="width: 90%; background: #d5d5d5; color: #7b7b7b; border:none;" class=" form-control" type="password" name="senha" placeholder="Senha">
                    </div>
                    <div class="d-flex d-sm-flex d-md-flex d-lg-flex d-xl-flex justify-content-center align-items-center justify-content-sm-center align-items-sm-center justify-content-md-center align-items-md-center justify-content-lg-center align-items-lg-center mb-3">
                        <button class="btn btn-primary " type="submit" style="width: 90%; background: #54d370;border-style: none;">
                            Acessar
                        </button>
                    </div>
                    
                </form>
            </div>
        </div>
    </div>
</section>