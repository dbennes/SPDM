<nav class="navbar navbar-expand-md fixed-top py-3" style="background: rgba(33,37,41,0);color: rgb(52,52,52);">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="#">
            <span style="color: #080808;letter-spacing: 7px;font-family: Montserrat, sans-serif;font-size: 16px;padding-left: 8px;">SPDM</span></a><button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-5"><span class="visually-hidden">Toggle navigation</span><i class="fas fa-bars" style="height: 10px;color: rgba(137,137,137,0.93);"></i></button>
        <div class="collapse navbar-collapse" id="navcol-5">
            <ul class="navbar-nav ms-auto">

            </ul>
                <a class="btn btn-dark ms-md-2" role="button" href="<?php echo $login; ?>" style="background: #66a96f;font-family: Montserrat, sans-serif;border-style: none;font-size: 11px;letter-spacing: 0px;border-radius: 0px;"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="currentColor" viewBox="0 0 16 16" class="bi bi-link-45deg" style="font-size: 13px;">
                    <path d="M4.715 6.542 3.343 7.914a3 3 0 1 0 4.243 4.243l1.828-1.829A3 3 0 0 0 8.586 5.5L8 6.086a1.002 1.002 0 0 0-.154.199 2 2 0 0 1 .861 3.337L6.88 11.45a2 2 0 1 1-2.83-2.83l.793-.792a4.018 4.018 0 0 1-.128-1.287z"></path>
                    <path d="M6.586 4.672A3 3 0 0 0 7.414 9.5l.775-.776a2 2 0 0 1-.896-3.346L9.12 3.55a2 2 0 1 1 2.83 2.83l-.793.792c.112.42.155.855.128 1.287l1.372-1.372a3 3 0 1 0-4.243-4.243L6.586 4.672z"></path>
                </svg>&nbsp; &nbsp; FAZER LOGIN </a>
        </div>
    </div>
</nav>